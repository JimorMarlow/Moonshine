#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t sig_pin;
  timer_t timer;
  uint32_t flow_rate_attr;
} chip_state_t;

// Колбэк-функция таймера
void timer_callback(void *user_data) {
  chip_state_t *chip = (chip_state_t*)user_data;
  
  // Генерируем короткий импульс
  pin_write(chip->sig_pin, HIGH);
  pin_write(chip->sig_pin, LOW);

  // Получаем текущее значение расхода из ползунка
  float current_flow = attr_read_float(chip->flow_rate_attr);
  
  // Рассчитываем период следования импульсов в микросекундах
  if (current_flow > 0.01) {
    float frequency = current_flow * 100.0; // 100 импульсов на литр/мин (условно)
    uint32_t period_us = (uint32_t)(1000000.0 / frequency);
    timer_start(chip->timer, period_us, true); // true = повторяющийся таймер
  } else {
    timer_stop(chip->timer);
  }
}

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));

  // Инициализация пинов
  pin_init("VCC", INPUT); 
  pin_init("GND", INPUT);
  chip->sig_pin = pin_init("SIG", OUTPUT_LOW);

  // Инициализация атрибута (ползунка) для управления расходом
  chip->flow_rate_attr = attr_init("flowRate", 1.0); 

  // --- ИСПРАВЛЕННАЯ ИНИЦИАЛИЗАЦИЯ ТАЙМЕРА ---
  // Создаем структуру конфигурации и передаем её в timer_init
  timer_config_t timer_config = {
    .callback = timer_callback,
    .user_data = chip
  };
  chip->timer = timer_init(&timer_config);
  
  // Запускаем таймер с начальным периодом (например, 10 000 мкс = 100 Гц)
  // Это заменит прямой вызов timer_callback, который был раньше
  timer_start(chip->timer, 10000, true); 

  printf("Water Flow Sensor SEN-HZ06D initialized.\n");
}