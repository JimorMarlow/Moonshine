#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct {
  pin_t hv1;
  pin_t hv2;
  pin_t hv;
  pin_t gnd_hv;
  pin_t hv3;
  pin_t hv4;
  pin_t lv1;
  pin_t lv2;
  pin_t lv;
  pin_t gnd_lv;
  pin_t lv3;
  pin_t lv4;
} chip_state_t;

void chip_init() {
  chip_state_t *chip = malloc(sizeof(chip_state_t));

  // Инициализация пинов высокого уровня (HV)
  chip->hv1 = pin_init("HV1", INPUT);
  chip->hv2 = pin_init("HV2", INPUT);
  chip->hv  = pin_init("HV", INPUT); // Питание HV
  chip->gnd_hv = pin_init("GND", INPUT); // Земля HV
  chip->hv3 = pin_init("HV3", INPUT);
  chip->hv4 = pin_init("HV4", INPUT);

  // Инициализация пинов низкого уровня (LV)
  chip->lv1 = pin_init("LV1", INPUT);
  chip->lv2 = pin_init("LV2", INPUT);
  chip->lv  = pin_init("LV", INPUT); // Питание LV
  chip->gnd_lv = pin_init("GND", INPUT); // Земля LV
  chip->lv3 = pin_init("LV3", INPUT);
  chip->lv4 = pin_init("LV4", INPUT);

  printf("Logic Level Converter 4CH initialized.\n");
}